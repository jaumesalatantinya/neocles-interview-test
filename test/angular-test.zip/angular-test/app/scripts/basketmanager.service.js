angular.module('angular-test').factory('BasketManager', function($http) {
  return {
    get: function(id) {
      return $http.get('http://localhost:8882/api/baskets/' + id).then(function(response) {
        return response.data;
      })
    }
  }
});
