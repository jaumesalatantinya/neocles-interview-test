angular.module('angular-test', []).controller('MainCtrl', function() {
  this.test = 'Hello world!';
});
