angular.module('angular-test').factory('ProductManager', function($http) {
  return {
    all: function() {
      return $http.get('http://localhost:8882/api/products').then(function(response) {
        return response.data;
      })
    }
  }
});
