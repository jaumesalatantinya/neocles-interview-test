angular.module('angular-test').directive('basket', function() {
  return {
    restrict: 'E',
    scope: true,
    template: '{{ vm.id }}',
    controllerAs: 'vm',
    bindToController: {
      id: '='
    },
    controller: function() {

    }
  }
});
