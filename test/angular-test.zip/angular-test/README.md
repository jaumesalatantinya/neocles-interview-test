### Script challenge

1. Basket overview

  Run `npm install` and `gulp serve` (`node_modules\.bin\gulp serve` if gulp isn't installed globally). You'll see a page
  that just says "Hello world!". Instead, we want to get an overview of our current basket (id: b1). We need to know which
  Products are in there, and in which quantity:

  | Product      | Quantity |
  | ------------ | --------:|
  | Nice shoe    |       14 |
  | Pretty Shirt |       20 |

2. Line details

  Now when the user clicks on a line, we want to know which sizes of that particular product are in the basket, and how
  many of them. The original basket contents should still be visible, while displaying the details, and the details need
  to be dismissible.
  
  Nice shoe:
  
  | Size     | 11 | 12 |
  | -------- | --:| --:|
  | Quantity |  8 |  6 |
  
  Pretty shirt:
  
  | Size     | M  | L  |
  | -------- | --:| --:|
  | Quantity | 20 |  0 |
  
  Note, we also want to know which sizes have *not* been selected, in the previous example, that's size L for Pretty
  shirt.
