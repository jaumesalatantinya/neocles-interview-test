// Karma configuration
// Generated on Mon Oct 06 2014 17:11:45 GMT+0200 (CEST)

module.exports = function(config) {
    var instance = process.env.instance;
    var path = require('path');

    config.set({
        frameworks: ['jasmine'],

        files: [
          "bower_components/angular/angular.js",
          "bower_components/angular-mocks/angular-mocks.js",
          "app/scripts/main.js",
          "app/scripts/*.js",
          "spec/*.js"
        ],

        port: 9876,
        colors: true,
        logLevel: config.LOG_INFO,
        autoWatch: true,
        browsers: ['PhantomJS'],
        singleRun: true
    });
};
