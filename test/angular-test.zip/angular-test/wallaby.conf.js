module.exports = function() {
   return {
        files: [
          "bower_components/angular/angular.js",
          "bower_components/angular-mocks/angular-mocks.js",
          "app/scripts/main.js",
          "app/scripts/*.js"
        ],

        tests: [
          "spec/*.js"
        ]
    };
};
