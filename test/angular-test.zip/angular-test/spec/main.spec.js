describe('The main functionality', function() {
  beforeEach(angular.mock.module('angular-test'));

  it('shows the basket contents', inject(function ($rootScope, $controller) {
    var $scope = $rootScope;
    var controller = $controller('MainCtrl', {$scope: $scope});

    expect(controller.test).toBe('Hello world!');
  }));
});
