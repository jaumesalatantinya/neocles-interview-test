describe('The basket manager', function() {
  beforeEach(angular.mock.module('angular-test'));

  it('fetches the basket', inject(function (BasketManager, $httpBackend) {
    $httpBackend.expectGET('http://localhost:8882/api/baskets/b1').respond({ basketId: 'b1' });

    BasketManager.get('b1').then(function(basket) {
      expect(basket).toEqual({ basketId: 'b1' });
    });

    $httpBackend.flush();
  }));
});
