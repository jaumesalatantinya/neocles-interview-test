describe('The basket directive', function() {
  var compile;

  beforeEach(angular.mock.module('angular-test'));
  beforeEach(inject(function($compile, $rootScope) {
    compile = function(template) {
      return $compile(template)($rootScope);
    }
  }));

  it('compiles', inject(function ($rootScope, $compile) {
    var $element = compile('<basket id="5"></basket>');
    var $scope = $element.scope();

    expect($scope.vm.id).toEqual(5);
  }));

  it('fills the template', inject(function ($rootScope, $compile) {
    var $element = compile('<basket id="6"></basket>');
    $rootScope.$apply();

    expect($element.text()).toEqual("6");
  }));
});

