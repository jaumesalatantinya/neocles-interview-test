describe('The product manager', function() {
  beforeEach(angular.mock.module('angular-test'));

  it('fetches the basket', inject(function (ProductManager, $httpBackend) {
    $httpBackend.expectGET('http://localhost:8882/api/products').respond([ { productId: 'b1' } ]);

    ProductManager.all().then(function(products) {
      expect(products).toEqual([ { productId: 'b1' } ]);
    });

    $httpBackend.flush();
  }));
});
